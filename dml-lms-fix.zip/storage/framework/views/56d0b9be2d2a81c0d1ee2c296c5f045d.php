<div class="px-6 py-4 bg-gray-50 dark:bg-gray-700/30 flex items-center justify-end gap-2">
    <?php echo e($slot); ?>

</div><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\modal-footer.blade.php ENDPATH**/ ?>