<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['color' => 'dark']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['color' => 'dark']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?> 

<?php
$map = [
'gray' => 'bg-soft text-dark border-soft',
'dark' => 'bg-dark/10 text-dark border-dark/20',
'brand' => 'bg-brand/10 text-brand border-brand/20',
'accent' => 'bg-accent/10 text-accent border-accent/20',
'danger' => 'bg-danger/10 text-danger border-danger/20',
];
?>

<span <?php echo e($attributes->merge(['class' => "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border
    {$map[$color]}"])); ?>>
    <?php echo e($slot); ?>

</span><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\badge.blade.php ENDPATH**/ ?>