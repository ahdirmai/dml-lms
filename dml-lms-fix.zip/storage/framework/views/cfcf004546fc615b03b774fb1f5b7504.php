<thead class="bg-gray-50 dark:bg-gray-700/40">
    <tr>
        <?php echo e($slot); ?>

    </tr>
</thead><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\thead.blade.php ENDPATH**/ ?>