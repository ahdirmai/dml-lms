<tbody class="divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-gray-800">
    <?php echo e($slot); ?>

</tbody><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\tbody.blade.php ENDPATH**/ ?>