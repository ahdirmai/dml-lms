<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label' => 'Label', 'value' => '0', 'suffix' => null, 'border' => 'brand']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label' => 'Label', 'value' => '0', 'suffix' => null, 'border' => 'brand']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?> 

<?php
$borderMap = [
'brand' => 'border-brand',
'accent' => 'border-accent',
'danger' => 'border-danger',
'dark' => 'border-dark',
'gray' => 'border-gray-400',
];
$textMap = [
'brand' => 'text-brand',
'accent' => 'text-accent',
'danger' => 'text-danger',
'dark' => 'text-dark',
'gray' => 'text-gray-500',
];
?>

<?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => ['hover' => false,'pad' => 'p-6','class' => 'border-l-4 '.$borderMap[$border]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['hover' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'pad' => 'p-6','class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('border-l-4 '.$borderMap[$border])]); ?>
    <p class="text-sm text-dark/70"><?php echo e($label); ?></p>
    <p class="text-4xl font-extrabold mt-1 <?php echo e($textMap[$border]); ?>">
        <?php echo e($value); ?>

        <?php if($suffix): ?>
        <span class="text-lg font-semibold ml-1 text-dark/60"><?php echo e($suffix); ?></span>
        <?php endif; ?>
    </p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\stat.blade.php ENDPATH**/ ?>