<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'variant' => 'primary', // primary|secondary|outline|danger|subtle|link
'size' => 'md',
'as' => 'button',
'href' => null,
'type' => 'button',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'variant' => 'primary', // primary|secondary|outline|danger|subtle|link
'size' => 'md',
'as' => 'button',
'href' => null,
'type' => 'button',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
$base = 'inline-flex items-center justify-center font-semibold rounded-lg transition focus:outline-none focus:ring-2
focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed';
$sizes = [
'sm' => 'px-3 py-1.5 text-sm',
'md' => 'px-4 py-2 text-sm',
'lg' => 'px-5 py-2.5 text-base',
];
$variants = [
'primary' => 'bg-brand text-white hover:brightness-95 focus:ring-brand',
'secondary' => 'bg-dark text-white hover:brightness-95 focus:ring-dark',
'outline' => 'border border-dark text-dark hover:bg-soft focus:ring-dark',
'danger' => 'bg-danger text-white hover:brightness-95 focus:ring-danger',
'subtle' => 'bg-soft text-dark hover:brightness-95 focus:ring-brand',
'link' => 'text-brand hover:underline focus:ring-brand',
];
$classes = "$base {$sizes[$size]} {$variants[$variant]}";
?>

<?php if($as === 'a'): ?>
<a href="<?php echo e($href); ?>" <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($slot); ?>

</a>
<?php else: ?>
<button type="<?php echo e($type); ?>" <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($slot); ?>

</button>
<?php endif; ?><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\button.blade.php ENDPATH**/ ?>