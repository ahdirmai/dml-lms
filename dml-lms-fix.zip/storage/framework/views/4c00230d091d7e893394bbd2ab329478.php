<div class="px-6 py-4">
    <?php echo e($slot); ?>

</div><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\modal-body.blade.php ENDPATH**/ ?>