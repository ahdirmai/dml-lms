<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['variant' => 'info', 'title' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['variant' => 'info', 'title' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?> 

<?php
$map = [
'info' => 'bg-accent/10 text-accent border-accent/20',
'success' => 'bg-brand/10 text-brand border-brand/20',
'warning' => 'bg-dark/10 text-dark border-dark/20',
'danger' => 'bg-danger/10 text-danger border-danger/20',
];
?>

<div <?php echo e($attributes->merge(['class' => "border rounded-lg p-4 {$map[$variant]}"])); ?>>
    <?php if($title): ?>
    <div class="font-semibold mb-1"><?php echo e($title); ?></div>
    <?php endif; ?>
    <div class="text-sm"><?php echo e($slot); ?></div>
</div><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\alert.blade.php ENDPATH**/ ?>