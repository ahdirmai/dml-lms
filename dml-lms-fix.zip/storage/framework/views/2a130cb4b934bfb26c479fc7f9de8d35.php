<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => config('app.name', 'LearnFlow')]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => config('app.name', 'LearnFlow')]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_','-',app()->getLocale())); ?>" class="h-full">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-soft min-h-screen antialiased">
    <?php
    /** @var \App\Models\User|null $me */
    $me = auth()->user();
    $roleNames = $me?->getRoleNames() ?? collect();
    $activeRole = $me?->active_role ?? $roleNames->first();

    $sidebarItems = [
    [
    'group' => null,
    'label' => 'Dashboard',
    'icon' => 'home',
    'href' => route('dashboard'),
    'active' => request()->routeIs('dashboard'),
    ]
    ];

    if ($activeRole === 'admin') {
    $sidebarItems = array_merge($sidebarItems, [[
    'group' => 'Course Management',
    'label' => 'Courses',
    'icon' => 'book',
    'href' => route('admin.courses.index'),
    'active' => request()->routeIs('admin.courses.*'),
    ],
    [
    'group' => 'Course Management',
    'label' => 'Categories',
    'icon' => 'folder',
    'href' => route('admin.categories.index'),
    'active' => request()->routeIs('admin.categories.*'),
    ],
    [
    'group' => 'Course Management',
    'label' => 'Tags',
    'icon' => 'tag',
    'href' => route('admin.tags.index'),
    'active' => request()->routeIs('admin.tags.*'),
    ],

    [
    'group' => 'Master Data',
    'label' => 'User Management',
    'icon' => 'users',
    'href' => route('admin.users.index'),
    'active' => request()->routeIs('admin.users.*'),
    ],
    [
    'group' => 'Master Data',
    'label' => 'Role Management',
    'icon' => 'shield-check',
    'href' => route('admin.roles.index'),
    'active' => request()->routeIs('admin.roles.*'),
    ],
    [
    'group' => 'Master Data',
    'label' => 'Permission Management',
    'icon' => 'key-square',
    'href' => route('admin.permissions.index'),
    'active' => request()->routeIs('admin.permissions.*'),
    ],
    ]);
    }

    if ($activeRole === 'instructor') {
    $sidebarItems = array_merge($sidebarItems, [[
    'group' => 'Course Management',
    'label' => 'Courses',
    'icon' => 'book',
    'href' => route('admin.courses.index'),
    'active' => request()->routeIs('admin.courses.*'),
    ],
    [
    'group' => 'Course Management',
    'label' => 'Categories',
    'icon' => 'folder',
    'href' => route('admin.categories.index'),
    'active' => request()->routeIs('admin.categories.*'),
    ],
    [
    'group' => 'Course Management',
    'label' => 'Tags',
    'icon' => 'tag',
    'href' => route('admin.tags.index'),
    'active' => request()->routeIs('admin.tags.*'),
    ],
    ]);
    }
    ?>

    <div class="flex min-h-screen">
        <?php if (isset($component)) { $__componentOriginal724cca1d6cfbd0d9b219a0d1bdb2d9a8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal724cca1d6cfbd0d9b219a0d1bdb2d9a8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.sidebar','data' => ['brand' => config('app.name'),'items' => $sidebarItems]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['brand' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(config('app.name')),'items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sidebarItems)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal724cca1d6cfbd0d9b219a0d1bdb2d9a8)): ?>
<?php $attributes = $__attributesOriginal724cca1d6cfbd0d9b219a0d1bdb2d9a8; ?>
<?php unset($__attributesOriginal724cca1d6cfbd0d9b219a0d1bdb2d9a8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal724cca1d6cfbd0d9b219a0d1bdb2d9a8)): ?>
<?php $component = $__componentOriginal724cca1d6cfbd0d9b219a0d1bdb2d9a8; ?>
<?php unset($__componentOriginal724cca1d6cfbd0d9b219a0d1bdb2d9a8); ?>
<?php endif; ?>

        <main class="ml-64 flex-1 p-6 lg:p-8">
            <?php if (isset($component)) { $__componentOriginal2766e652044d29fadbe900c7dc2d61fc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2766e652044d29fadbe900c7dc2d61fc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.topbar','data' => ['avatar' => auth()->user()->avatar_url ?? null,'header' => $header]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['avatar' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(auth()->user()->avatar_url ?? null),'header' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($header)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2766e652044d29fadbe900c7dc2d61fc)): ?>
<?php $attributes = $__attributesOriginal2766e652044d29fadbe900c7dc2d61fc; ?>
<?php unset($__attributesOriginal2766e652044d29fadbe900c7dc2d61fc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2766e652044d29fadbe900c7dc2d61fc)): ?>
<?php $component = $__componentOriginal2766e652044d29fadbe900c7dc2d61fc; ?>
<?php unset($__componentOriginal2766e652044d29fadbe900c7dc2d61fc); ?>
<?php endif; ?>



            <div class=" space-y-8">
                <?php echo e($slot); ?>

            </div>
        </main>
    </div>
</body>

</html><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\layouts\app.blade.php ENDPATH**/ ?>