<tr <?php echo e($attributes->merge(['class' => 'hover:bg-gray-50 dark:hover:bg-gray-700/30'])); ?>>
    <?php echo e($slot); ?>

</tr><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\tr.blade.php ENDPATH**/ ?>