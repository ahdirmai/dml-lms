<table <?php echo e($attributes->merge(['class' => 'min-w-full text-sm text-left divide-y divide-soft'])); ?>>
    <?php echo e($slot); ?>

</table><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\table.blade.php ENDPATH**/ ?>