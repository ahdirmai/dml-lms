<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['label' => null, 'for' => null, 'helper' => null, 'error' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['label' => null, 'for' => null, 'helper' => null, 'error' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div>
    <?php if($label): ?>
    <label for="<?php echo e($for); ?>" class="block text-sm font-medium text-dark mb-1">
        <?php echo e($label); ?>

        <?php if($attributes->get('required')): ?> <span class="text-danger">*</span> <?php endif; ?>
    </label>
    <?php endif; ?>

    <?php echo e($slot); ?>


    <?php if($helper): ?>
    <p class="text-xs text-dark/60 mt-1"><?php echo e($helper); ?></p>
    <?php endif; ?>

    <?php if($error): ?>
    <p class="text-xs text-danger mt-1"><?php echo e($error[0]); ?></p>
    <?php endif; ?>
</div><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\form-field.blade.php ENDPATH**/ ?>