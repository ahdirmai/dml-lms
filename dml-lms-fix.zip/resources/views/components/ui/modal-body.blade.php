<div class="px-6 py-4">
    {{ $slot }}
</div>