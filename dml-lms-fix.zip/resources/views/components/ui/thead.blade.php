<thead class="bg-gray-50 dark:bg-gray-700/40">
    <tr>
        {{ $slot }}
    </tr>
</thead>