<?php

namespace App\Models\Lms;

use Illuminate\Database\Eloquent\Model;

class CourseTag extends Model
{
    //
}
