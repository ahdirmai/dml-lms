<div class="px-6 py-4 bg-gray-50 dark:bg-gray-700/30 flex items-center justify-end gap-2">
    {{ $slot }}
</div>