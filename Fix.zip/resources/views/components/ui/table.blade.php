<table {{ $attributes->merge(['class' => 'min-w-full text-sm text-left divide-y divide-soft']) }}>
    {{ $slot }}
</table>