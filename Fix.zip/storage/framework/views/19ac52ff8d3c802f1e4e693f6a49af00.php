<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Kreator Hub'); ?></title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        "primary-accent": "#3498DB",
                        "secondary-highlight": "#2ECC71",
                        "background-soft": "#F5F7FA",
                    },
                    fontFamily: {
                        sans: ["Nunito", "Poppins", "sans-serif"],
                    },
                    boxShadow: {
                        "custom-soft": "0 10px 15px -3px rgba(52, 152, 219, 0.1), 0 4px 6px -2px rgba(52, 152, 219, 0.05)",
                    },
                },
            },
        };
    </script>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="bg-background-soft flex min-h-screen">
    <?php echo $__env->yieldContent('content'); ?>

</body>
<?php echo $__env->yieldPushContent('scripts'); ?>

</html><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\layouts\builder.blade.php ENDPATH**/ ?>