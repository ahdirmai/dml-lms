<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['brand' => 'LearnFlow', 'items' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['brand' => 'LearnFlow', 'items' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<aside class="w-64 bg-white p-6 shadow-xl flex flex-col fixed h-full overflow-y-auto">
    <div class="flex items-center mb-8 mt-1">
        <svg class="w-8 h-8 mr-2 text-brand" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M12 14l9-5-9-5-9 5 9 5zM12 14v6M7.5 7.5L12 10.5l4.5-3" />
        </svg>
        <h1 class="text-lg font-bold text-dark"><?php echo e($brand); ?></h1>
    </div>

    <nav class="space-y-4 mb-6">
        <?php $currentGroup = null; ?>

        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item['group'] !== $currentGroup): ?>
        <?php if($currentGroup !== null): ?>
        <div class="border-t border-gray-100 my-2"></div>
        <?php endif; ?>
        <?php if($item['group']): ?>
        <p class="text-xs uppercase font-semibold text-gray-400 mt-4 mb-2">
            <?php echo e($item['group']); ?>

        </p>
        <?php endif; ?>
        <?php $currentGroup = $item['group']; ?>
        <?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalc3d63d7b1a83c18ec7bb91d18c8eb16d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3d63d7b1a83c18ec7bb91d18c8eb16d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.nav-item','data' => ['href' => $item['href'],'active' => $item['active'],'icon' => $item['icon']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.nav-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['href']),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['active']),'icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['icon'])]); ?>
            <?php echo e($item['label']); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3d63d7b1a83c18ec7bb91d18c8eb16d)): ?>
<?php $attributes = $__attributesOriginalc3d63d7b1a83c18ec7bb91d18c8eb16d; ?>
<?php unset($__attributesOriginalc3d63d7b1a83c18ec7bb91d18c8eb16d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3d63d7b1a83c18ec7bb91d18c8eb16d)): ?>
<?php $component = $__componentOriginalc3d63d7b1a83c18ec7bb91d18c8eb16d; ?>
<?php unset($__componentOriginalc3d63d7b1a83c18ec7bb91d18c8eb16d); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>

    <div class="mt-auto pt-4 border-t border-soft">
        <p class="text-xs text-gray-400">v1.0 · <?php echo e(now()->format('M Y')); ?></p>
    </div>
</aside><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\sidebar.blade.php ENDPATH**/ ?>