<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => null, 'name' => 'modal']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => null, 'name' => 'modal']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
    <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-100"><?php echo e($title); ?></h3>
    <button x-on:click="$dispatch('close-<?php echo e($name); ?>')" class="p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-700">
        ✕
    </button>
</div><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\modal-header.blade.php ENDPATH**/ ?>