<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['avatar' => null,
'header'=>null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['avatar' => null,
'header'=>null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<header class="flex justify-between items-center bg-white p-4 rounded-xl shadow mb-6">
    
    <div class="relative w-full max-w-sm">
        <?php if(isset($header)): ?>
        
            <h2 class="text-xl font-semibold text-dark">
                <?php echo e($header); ?>

            </h2>
            
        <?php endif; ?>
    </div>

    
    <div class="flex items-center space-x-4 ml-4">
        <button class="relative p-2 text-dark hover:text-dark bg-soft rounded-full">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M15 17h5l-1.4-1.4A2 2 0 0118 13.5V10a6 6 0 00-6-6H5v10l2 2v2h10z" />
            </svg>
            <span class="absolute top-1 right-1 h-2 w-2 rounded-full bg-accent"></span>
        </button>

        
        <?php
        $user = auth()->user();
        $roleNames = $user?->getRoleNames() ?? collect();
        $activeRole = $user?->active_role ?? $roleNames->first();
        ?>

        <div class="relative" x-data="{ open: false }" @click.outside="open = false">
            <button @click="open = !open"
                class="flex items-center focus:outline-none focus:ring-2 focus:ring-brand rounded-full">
                <img src="<?php echo e($avatar ?? 'https://via.placeholder.com/40'); ?>" alt="User Avatar"
                    class="w-10 h-10 rounded-full border-2 border-brand shadow">
            </button>

            
            <div x-cloak x-show="open" x-transition
                class="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-lg border border-soft overflow-hidden z-50">
                <div class="px-4 py-3 border-b border-soft">
                    <p class="text-sm font-semibold text-dark"><?php echo e($user?->name); ?></p>
                    <p class="text-xs text-dark/60 truncate"><?php echo e($user?->email); ?></p>
                </div>

                
                <?php if($roleNames->count() > 0): ?>
                <div class="px-4 py-3 border-b border-soft">
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-xs uppercase tracking-wide text-dark/60">Active Role</span>
                        <span
                            class="inline-flex items-center px-2 py-0.5 text-xs font-medium rounded bg-brand/10 text-brand border border-brand/20">
                            <?php echo e(Str::headline($activeRole)); ?>

                        </span>
                    </div>

                    
                    <?php if($roleNames->count() > 1): ?>
                    <form action="<?php echo e(route('switch.role')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <select name="role" onchange="this.form.submit()"
                            class="w-full rounded-lg border border-soft px-2 py-1.5 text-sm text-dark bg-white focus:ring-2 focus:ring-brand focus:border-brand">
                            <?php $__currentLoopData = $roleNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role); ?>" <?php if($activeRole===$role): echo 'selected'; endif; ?>>
                                <?php echo e(Str::headline($role)); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </form>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                
                <div class="py-2">
                    <a href="<?php echo e(route('profile.edit')); ?>"
                        class="block px-4 py-2.5 text-sm text-dark hover:bg-soft transition">
                        Profile
                    </a>

                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                            class="w-full text-left px-4 py-2.5 text-sm text-danger hover:bg-danger/10">
                            Log Out
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\topbar.blade.php ENDPATH**/ ?>