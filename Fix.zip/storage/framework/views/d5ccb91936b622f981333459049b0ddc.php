<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'name' => 'modal',
'maxWidth' => 'lg', // sm|md|lg|xl|2xl
'show' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'name' => 'modal',
'maxWidth' => 'lg', // sm|md|lg|xl|2xl
'show' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
$maxMap = [
'sm' => 'sm:max-w-sm',
'md' => 'sm:max-w-md',
'lg' => 'sm:max-w-lg',
'xl' => 'sm:max-w-xl',
'2xl'=> 'sm:max-w-2xl',
];
?>

<div x-data="{ open: <?php echo \Illuminate\Support\Js::from($show)->toHtml() ?> }" x-on:open-<?php echo e($name); ?>.window="open = true" x-on:close-<?php echo e($name); ?>.window="open = false">
    <div x-show="open" class="fixed inset-0 z-50 flex items-center justify-center p-4" style="display:none;">
        <div x-show="open" x-transition.opacity class="fixed inset-0 bg-black/40"></div>

        <div x-show="open" x-transition
            class="relative bg-white dark:bg-gray-800 rounded-xl shadow-xl w-full <?php echo e($maxMap[$maxWidth]); ?> mx-auto overflow-hidden">
            <?php echo e($slot); ?>

        </div>
    </div>
</div><?php /**PATH C:\Ahdirmai\Work\side-project\dml-lms-fix\resources\views\components\ui\modal.blade.php ENDPATH**/ ?>